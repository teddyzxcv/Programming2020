using System;
using System.Collections.Generic;

public partial class TestSystem
{
    public static List<User> UserList = new List<User>();
    public void Add(string username)
    {
        User newuser = new User(username);
        if (UserList.Contains(newuser))
            throw new ArgumentException("User already exists");
        UserList.Add(newuser);
        Notifications += newuser.SendMessage;
    }

    public void Remove(string username)
    {
        User deleteuser = new User(username);
        if (!UserList.Contains(deleteuser))
            throw new ArgumentException("User does not exist");
        UserList.Remove(deleteuser);
        Notifications = null;
        for (int i = 0; i < UserList.Count; i++)
        {
            Notifications += UserList[i].SendMessage;
        }
    }


}