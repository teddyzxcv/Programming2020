using System;
using System.Collections.Generic;

public class User
{

    private string name;
    public User(string username)
    {
        this.name = username;
    }
    private List<string> messagearchive = new List<string>();

    public override string ToString() => name;

    public void SendMessage(string text)
    {
        Console.WriteLine($"-{name}-");
        if (messagearchive.Count > 0)
        {
            Console.WriteLine("Received notifications:");
            for (int i = 0; i < messagearchive.Count; i++)
            {
                Console.WriteLine(messagearchive[i]);
            }
        }
        Console.WriteLine($"New notification: {text}");
        messagearchive.Add(text);
    }

}